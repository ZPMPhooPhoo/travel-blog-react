import Login from "../../components/loginform";
export default function login(){
    return(
        <Login/>
    );

}