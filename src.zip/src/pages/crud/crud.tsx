
import CRUD from "../../components/CRUD";

const CRUDPage = () => {
  return (
    <>

      {<CRUD />}
    </>
  );
}

export default CRUDPage;





